# User Profile Page Wireframe

- **Header**:
  - Profile Picture (left)
  - Username and Bio (center)
  - Edit Profile Button (right)
- **Main Content**:
  - **User's Posts**:
    - List of user's posts, photos, and videos
  - **Sidebar**:
    - Friends list
    - Groups
    - Pages