const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const authMiddleware = require('../middleware/authMiddleware');

// Middleware to check if the user is an admin
const isAdmin = (req, res, next) => {
  if (req.user && req.user.isAdmin) {
    next();
  } else {
    res.status(403).send('Access denied');
  }
};

router.use(authMiddleware);
router.use(isAdmin);

router.post('/verify-kyc', adminController.verifyUserKYC);
router.get('/vip-subscriptions', adminController.monitorVIPSubscriptions);
router.post('/manage-users', adminController.manageUsers);
router.get('/track-activity', adminController.trackUserActivity);
router.get('/monitor-messages', adminController.monitorMessages);

module.exports = router;