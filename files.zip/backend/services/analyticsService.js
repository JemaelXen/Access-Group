const User = require('../models/User');
const Post = require('../models/Post');
const mongoose = require('mongoose');

const trackUserEngagement = async () => {
  try {
    const userCount = await User.countDocuments();
    const postCount = await Post.countDocuments();

    // Additional analytics logic here

    return { userCount, postCount };
  } catch (error) {
    console.error('User engagement tracking error:', error);
    throw new Error('User engagement tracking failed');
  }
};

module.exports = { trackUserEngagement };