const User = require('../models/User');

const updateSubscription = async (userId, subscriptionLevel) => {
  try {
    const user = await User.findById(userId);
    if (!user) throw new Error('User not found');

    user.isVIP = true;
    user.subscriptionLevel = subscriptionLevel;
    await user.save();

    return user;
  } catch (error) {
    console.error('Subscription update error:', error);
    throw new Error('Subscription update failed');
  }
};

module.exports = { updateSubscription };