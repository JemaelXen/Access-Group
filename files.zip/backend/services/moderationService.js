const axios = require('axios');

const moderateContent = async (content) => {
  try {
    const response = await axios.post('https://ai-moderation-service.com/moderate', {
      content,
    });
    return response.data;
  } catch (error) {
    console.error('Content moderation error:', error);
    throw new Error('Content moderation failed');
  }
};

module.exports = { moderateContent };