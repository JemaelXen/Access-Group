const axios = require('axios');

const generateLeads = async (seoContent) => {
  try {
    const response = await axios.post('https://lead-generation-service.com/generate', {
      content: seoContent,
    });
    return response.data;
  } catch (error) {
    console.error('Error generating leads:', error);
    throw new Error('Failed to generate leads');
  }
};

module.exports = { generateLeads };