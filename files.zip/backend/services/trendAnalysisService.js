const axios = require('axios');

const getDailyTrends = async () => {
  try {
    const response = await axios.get('https://trends.google.com/trends/api/dailytrends', {
      params: {
        geo: 'US',
      },
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching daily trends:', error);
    throw new Error('Failed to fetch daily trends');
  }
};

module.exports = { getDailyTrends };