const axios = require('axios');

const generateSeoContent = async (trend) => {
  try {
    const response = await axios.post('https://ai-content-generator.com/generate', {
      prompt: `Generate SEO content for the trend: ${trend}`,
    });
    return response.data;
  } catch (error) {
    console.error('Error generating SEO content:', error);
    throw new Error('Failed to generate SEO content');
  }
};

module.exports = { generateSeoContent };