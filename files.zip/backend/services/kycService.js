const axios = require('axios');

const verifyKYC = async (userId, governmentId, faceScan, irisScan) => {
  try {
    const response = await axios.post('https://ai-kyc-service.com/verify', {
      userId,
      governmentId,
      faceScan,
      irisScan,
    });
    return response.data;
  } catch (error) {
    console.error('KYC verification error:', error);
    throw new Error('KYC verification failed');
  }
};

module.exports = { verifyKYC };