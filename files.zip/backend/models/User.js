const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  isVerified: { type: Boolean, default: false },
  isVIP: { type: Boolean, default: false },
  isBanned: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
  kycStatus: { type: String, default: 'pending' }, // New field for KYC status
  isAdmin: { type: Boolean, default: false }, // New field for admin role
  // Additional fields for KYC, subscriptions, etc.
});

module.exports = mongoose.model('User', UserSchema);