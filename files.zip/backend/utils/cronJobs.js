const cron = require('node-cron');
const { getDailyTrends } = require('../services/trendAnalysisService');
const { generateSeoContent } = require('../services/seoContentService');
const { generateLeads } = require('../services/leadGenerationService');

// Schedule daily lead and SEO generation
cron.schedule('0 0 * * *', async () => {
  try {
    const dailyTrends = await getDailyTrends();
    for (const trend of dailyTrends.trendingSearchesDays[0].trendingSearches) {
      const seoContent = await generateSeoContent(trend.title.query);
      await generateLeads(seoContent);
    }
    console.log('Daily lead and SEO generation completed');
  } catch (error) {
    console.error('Daily lead and SEO generation error:', error);
  }
});