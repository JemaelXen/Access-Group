# Access Social Media Platform

Access is a next-generation social media platform designed to provide a diverse and engaging online experience. It combines features from Twitter/X, Litmatch, live streaming, e-books, trading, and even casino gaming.

## Features

- **Twitter/X Features**
  - Posting, commenting, reacting, sharing, MyDay, page creation, group pages, messaging for mutual friends, adding/unfriending, following/unfollowing, blocking/restricting, and custom post visibility settings.
- **Litmatch Features**
  - Live room interactions for random socializing, debate rooms, and live forums.
- **Casino Section**
  - Accessible to users 18+, supporting casino games with top-up wallets and withdrawal options via PayPal, debit card, or e-wallets.
- **Trading Section**
  - Accessible to users 16+, enabling the buying and selling of company shares worldwide, including Access Group shares.
- **Live Streaming**
  - Users can go live alone or with friends, receive gifts, and manage a wallet for transactions.
- **E-Book Section**
  - A collection of all existing worldwide books in digital format.
- **User Verification (KYC)**
  - Government ID, face scan, and approval within 30 minutes for account authentication.
- **VIP Subscription System**
  - VIP rankings based on investment and subscription tiers.
- **User Profile Customization**
  - Avatar uploads, profile pictures, bios, links, and customizable fonts.
- **Admin Dashboard**
  - Exclusive to Jemael, enabling modifications, monitoring, and privacy control.
- **Payment System**
  - All payments for gifts, casino top-ups, and fonts go to Lead Bank (Account #210193271135, Routing #101019644).
- **Inspirational Section**
  - An 'About Us' page featuring founder details (Aries, 20 years old, NU Psychology major) and the platform's mission to connect people worldwide.
- **Communication Features**
  - Integrated video calls, voice calls, voice messages, and emoji support.
- **Two-Factor Authentication**
  - Enhanced security for all users.

## Mission & Vision

**Mission**: To provide a diverse, secure, and interactive social media platform that enables users to connect, share, trade, and engage with one another globally.

**Vision**: To revolutionize the online social experience by integrating multiple social, business, and entertainment aspects into one unified platform.